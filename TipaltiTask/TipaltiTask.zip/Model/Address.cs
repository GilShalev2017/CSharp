﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TipaltiTask.Model
{
    class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
    }
}
